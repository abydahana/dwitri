		<div class="text-center errorpadding first-child">
			<div class="container">
				<div class="row">
					<div class="col-sm-8 col-sm-offset-2 animated shake text-center">
						<div style="height:100px;"></div>
						<img src="<?php echo base_url('themes/' . $this->settings['theme'] . '/images/large_logo.png'); ?>" style="max-width:260px" />
						<br /><br />
						<h1><?php echo $meta['title']; ?></h1>
						<p><?php echo $meta['descriptions']; ?></p>
						<br /><br />
					</div>
				</div>
			</div> 
		</div>
<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

	$config['appId']	= '423905061028802';
	$config['secret']  	= 'e2a22d2b0e271a75cd7c36e030c9ebc3';
	$config['cookie']  	= TRUE;